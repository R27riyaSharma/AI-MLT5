"""Stock Price Trend Prediction with LSTM.

Pipeline: fetch (yfinance) -> indicators (SMA, RSI) -> scale -> windows ->
LSTM (Keras) -> train/validate -> evaluate -> plots.

Run:  python stock_lstm.py --ticker AAPL --years 5 --epochs 30
"""
import argparse
import os

import numpy as np
import pandas as pd

FEATURES = ["Close", "SMA_20", "SMA_50", "RSI_14"]


# ---------- 1. Data ----------
def fetch_data(ticker: str, years: int = 5) -> pd.DataFrame:
    """Download daily OHLCV data from Yahoo Finance."""
    import yfinance as yf

    df = yf.download(ticker, period=f"{years}y", auto_adjust=True, progress=False)
    if isinstance(df.columns, pd.MultiIndex):  # newer yfinance returns multi-index
        df.columns = df.columns.get_level_values(0)
    if df.empty:
        raise ValueError(f"No data returned for ticker '{ticker}'")
    return df[["Open", "High", "Low", "Close", "Volume"]].dropna()


# ---------- 2. Indicators ----------
def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """Relative Strength Index using Wilder's smoothing."""
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).fillna(100.0).where(avg_gain.notna())


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["SMA_20"] = out["Close"].rolling(20).mean()
    out["SMA_50"] = out["Close"].rolling(50).mean()
    out["RSI_14"] = rsi(out["Close"], 14)
    return out.dropna()


# ---------- 3. Scaling + windows ----------
class MinMax:
    """Min-max scaler fit on the training split only (avoids look-ahead leakage)."""

    def fit(self, x):
        self.lo, self.hi = x.min(axis=0), x.max(axis=0)
        self.rng = np.where(self.hi - self.lo == 0, 1.0, self.hi - self.lo)
        return self

    def transform(self, x):
        return (x - self.lo) / self.rng

    def inverse_close(self, x, close_idx=0):
        return x * self.rng[close_idx] + self.lo[close_idx]


def make_windows(arr: np.ndarray, lookback: int, target_col: int = 0):
    """X[i] = arr[i:i+lookback], y[i] = target at the next step."""
    X, y = [], []
    for i in range(len(arr) - lookback):
        X.append(arr[i : i + lookback])
        y.append(arr[i + lookback, target_col])
    return np.array(X), np.array(y)


def prepare(df: pd.DataFrame, lookback: int = 60, train_frac: float = 0.8):
    data = df[FEATURES].values.astype("float64")
    split = int(len(data) * train_frac)
    scaler = MinMax().fit(data[:split])
    scaled = scaler.transform(data)
    X, y = make_windows(scaled, lookback)
    # window i predicts row i+lookback; keep split aligned to the raw timeline
    n_train = split - lookback
    dates = df.index[lookback:]
    return {
        "X_train": X[:n_train], "y_train": y[:n_train],
        "X_test": X[n_train:], "y_test": y[n_train:],
        "dates_test": dates[n_train:], "scaler": scaler,
    }


# ---------- 4. Model ----------
def build_model(lookback: int, n_features: int):
    from tensorflow import keras
    from tensorflow.keras import layers

    model = keras.Sequential([
        layers.Input(shape=(lookback, n_features)),
        layers.LSTM(64, return_sequences=True),
        layers.Dropout(0.2),
        layers.LSTM(32),
        layers.Dropout(0.2),
        layers.Dense(16, activation="relu"),
        layers.Dense(1),
    ])
    model.compile(optimizer=keras.optimizers.Adam(1e-3), loss="mse")
    return model


def train(model, d, epochs=30, batch_size=32):
    from tensorflow import keras

    cbs = [keras.callbacks.EarlyStopping(patience=6, restore_best_weights=True)]
    return model.fit(
        d["X_train"], d["y_train"], validation_split=0.1,
        epochs=epochs, batch_size=batch_size, shuffle=False, callbacks=cbs, verbose=2,
    )


# ---------- 5. Evaluation ----------
def metrics(actual, pred):
    err = pred - actual
    return {
        "RMSE": float(np.sqrt(np.mean(err**2))),
        "MAE": float(np.mean(np.abs(err))),
        "MAPE_%": float(np.mean(np.abs(err / actual)) * 100),
        # share of days where the predicted direction of change matched reality
        "Directional_acc_%": float(
            np.mean(np.sign(np.diff(pred)) == np.sign(np.diff(actual))) * 100
        ),
    }


def predict_prices(model, d):
    p = model.predict(d["X_test"], verbose=0).ravel()
    sc = d["scaler"]
    return sc.inverse_close(d["y_test"]), sc.inverse_close(p)


def forecast_next(model, df, scaler, lookback=60):
    """Next-day close forecast from the most recent `lookback` days."""
    window = scaler.transform(df[FEATURES].values[-lookback:].astype("float64"))
    p = model.predict(window[None, ...], verbose=0)[0, 0]
    return float(scaler.inverse_close(p))


# ---------- 6. Plots ----------
def save_plots(df, d, actual, pred, history, outdir, ticker):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(outdir, exist_ok=True)

    plt.figure(figsize=(10, 4.5))
    plt.plot(d["dates_test"], actual, label="Actual")
    plt.plot(d["dates_test"], pred, label="LSTM prediction")
    plt.title(f"{ticker}: predicted vs actual close (test set)")
    plt.ylabel("Price"); plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "pred_vs_actual.png"), dpi=150); plt.close()

    plt.figure(figsize=(6, 4))
    plt.plot(history.history["loss"], label="train")
    plt.plot(history.history["val_loss"], label="validation")
    plt.title("Training loss (MSE)"); plt.xlabel("Epoch"); plt.legend(); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "loss_curve.png"), dpi=150); plt.close()

    fig, ax = plt.subplots(2, 1, figsize=(10, 6), sharex=True,
                           gridspec_kw={"height_ratios": [3, 1]})
    ax[0].plot(df.index, df["Close"], label="Close")
    ax[0].plot(df.index, df["SMA_20"], label="SMA 20")
    ax[0].plot(df.index, df["SMA_50"], label="SMA 50")
    ax[0].legend(); ax[0].set_title(f"{ticker}: price with moving averages")
    ax[1].plot(df.index, df["RSI_14"], color="purple")
    ax[1].axhline(70, ls="--", c="r"); ax[1].axhline(30, ls="--", c="g")
    ax[1].set_ylabel("RSI 14"); plt.tight_layout()
    plt.savefig(os.path.join(outdir, "indicators.png"), dpi=150); plt.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ticker", default="AAPL")
    ap.add_argument("--years", type=int, default=5)
    ap.add_argument("--lookback", type=int, default=60)
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--out", default="outputs")
    a = ap.parse_args()

    df = add_indicators(fetch_data(a.ticker, a.years))
    d = prepare(df, a.lookback)
    model = build_model(a.lookback, len(FEATURES))
    hist = train(model, d, a.epochs)

    actual, pred = predict_prices(model, d)
    m = metrics(actual, pred)
    # naive baseline: tomorrow's price = today's price
    naive = metrics(actual[1:], actual[:-1])
    print("LSTM    :", {k: round(v, 3) for k, v in m.items()})
    print("Baseline:", {k: round(v, 3) for k, v in naive.items()})

    os.makedirs(a.out, exist_ok=True)
    model.save(os.path.join(a.out, "lstm_model.keras"))
    model.save_weights(os.path.join(a.out, "lstm.weights.h5"))
    save_plots(df, d, actual, pred, hist, a.out, a.ticker)
    print("Next-day forecast:", round(forecast_next(model, df, d["scaler"], a.lookback), 2))
    print("Saved model, weights and plots to", a.out)


if __name__ == "__main__":
    main()
