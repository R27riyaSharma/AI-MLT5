# Stock Price Trend Prediction with LSTM

Predicts the next-day closing price from the past 60 days of price, 20/50-day
moving averages and RSI(14), using a 2-layer Keras LSTM. Includes a Streamlit dashboard.

## Setup
```
pip install -r requirements.txt
```

## Train from the command line
```
python stock_lstm.py --ticker AAPL --years 5 --epochs 30
```
Creates `outputs/` with `lstm_model.keras`, `lstm.weights.h5`, `pred_vs_actual.png`,
`loss_curve.png`, `indicators.png`, and prints LSTM vs naive-baseline metrics.

## Dashboard
```
streamlit run app.py
```
To deploy: push this folder to GitHub, then create an app on Streamlit Community Cloud
pointing at `app.py`.

## Files
- `stock_lstm.py`: data fetch, indicators, scaling, windowing, model, metrics, plots
- `app.py`: Streamlit dashboard
- `test_pipeline.py`: offline check of indicators/windowing/alignment (no TensorFlow needed)

## Design notes
- Scaler is fit on the training split only, so no future information leaks in.
- Train/test split is chronological (80/20), never shuffled.
- Results are compared with a naive "tomorrow = today" baseline; stock prices are close
  to a random walk, so beating it is the honest test.
