"""Offline sanity checks on synthetic prices. Run: python test_pipeline.py"""
import numpy as np
import pandas as pd

import stock_lstm as sl

rng = np.random.default_rng(0)
n = 1200
close = 100 * np.exp(np.cumsum(rng.normal(0.0004, 0.015, n)))
df = pd.DataFrame({"Close": close}, index=pd.bdate_range("2021-01-01", periods=n))
df = sl.add_indicators(df)

assert df["RSI_14"].between(0, 100).all(), "RSI out of range"
d = sl.prepare(df, 60)
split = int(len(df) * 0.8)
actual = d["scaler"].inverse_close(d["y_test"])
assert np.allclose(actual, df["Close"].values[split:]), "test windows misaligned"
assert d["X_train"].min() >= 0 and d["X_train"].max() <= 1.0 + 1e-9, "scaling leak/overflow"
print("All checks passed.")
