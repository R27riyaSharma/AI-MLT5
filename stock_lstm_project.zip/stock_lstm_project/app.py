"""Streamlit dashboard: pick a ticker, train an LSTM, see predictions + indicators.

Run:  streamlit run app.py
"""
import pandas as pd
import streamlit as st

import stock_lstm as sl

st.set_page_config(page_title="Stock LSTM Dashboard", layout="wide")
st.title("Stock Price Trend Prediction with LSTM")
st.caption("Educational project. Not financial advice.")

with st.sidebar:
    ticker = st.text_input("Ticker", "AAPL").upper().strip()
    years = st.slider("Years of history", 2, 10, 5)
    lookback = st.slider("Lookback window (days)", 20, 120, 60, step=10)
    epochs = st.slider("Epochs", 5, 60, 20)
    run = st.button("Train and predict", type="primary")


@st.cache_data(show_spinner="Downloading data...")
def load(ticker, years):
    return sl.add_indicators(sl.fetch_data(ticker, years))


try:
    df = load(ticker, years)
except Exception as e:
    st.error(f"Could not load data for '{ticker}': {e}")
    st.stop()

c1, c2 = st.columns(2)
c1.subheader("Price with moving averages")
c1.line_chart(df[["Close", "SMA_20", "SMA_50"]])
c2.subheader("RSI (14)  |  above 70 overbought, below 30 oversold")
c2.line_chart(df["RSI_14"])

if run:
    d = sl.prepare(df, lookback)
    model = sl.build_model(lookback, len(sl.FEATURES))
    bar = st.progress(0.0, text="Training...")

    from tensorflow import keras

    class Progress(keras.callbacks.Callback):
        def on_epoch_end(self, epoch, logs=None):
            bar.progress((epoch + 1) / epochs, text=f"Epoch {epoch + 1}/{epochs}")

    model.fit(d["X_train"], d["y_train"], validation_split=0.1, epochs=epochs,
              batch_size=32, shuffle=False, verbose=0, callbacks=[Progress()])
    bar.empty()

    actual, pred = sl.predict_prices(model, d)
    m = sl.metrics(actual, pred)
    base = sl.metrics(actual[1:], actual[:-1])

    st.subheader("Predicted vs actual (test set)")
    st.line_chart(pd.DataFrame({"Actual": actual, "LSTM": pred}, index=d["dates_test"]))

    cols = st.columns(4)
    cols[0].metric("RMSE", f"{m['RMSE']:.2f}", f"baseline {base['RMSE']:.2f}", delta_color="off")
    cols[1].metric("MAE", f"{m['MAE']:.2f}")
    cols[2].metric("MAPE", f"{m['MAPE_%']:.2f}%")
    cols[3].metric("Direction accuracy", f"{m['Directional_acc_%']:.1f}%")
    st.info("Baseline = predicting tomorrow's price equals today's. "
            "A useful model should beat it on RMSE.")

    nxt = sl.forecast_next(model, df, d["scaler"], lookback)
    st.metric("Next-day close forecast", f"{nxt:.2f}")
else:
    st.write("Set the options in the sidebar and press **Train and predict**.")
